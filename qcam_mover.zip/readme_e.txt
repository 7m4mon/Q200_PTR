QCAM MOVER by 7M4MON 2011,2015

This application controls mechanical pan and tilt of Qcam Orbit AF QCAM-200R.

I tested driver version 13.31.1044.0 that installed by windows update.

This application includes two execute files.
1.QCAM_PTR.exe
This is the main file of QCAM MOVER developed on Visual C++ 2010 Express edition.
QCAM_PTR has 4 arguments. You can also omit these parameters.
First, Relative Pan angle. default:180
Second, Relative Tilt angle. default:180
Third, Wait time of initial move. default:100 (ms)
Forth, Waiting time of moving per 1 digit. default:9 (ms)

So, if you want to move right to 40 digits and down to 10 digits, you should execute as follows:

"QCAM_PTR.exe -40 10"

If your QCAM moves slow, and that did not end moving until waiting time, then you should address arguments like...

"QCAM_PTR.exe -40 10 300 20"

My QCAM has 128 steps for horizontal direction, and 54 steps for vertical direction.
So, to initialize, you have to execute two commands.
"QCAM_PTR.exe 180 180" and "QCAM_PTR.exe -64 -27"

For more details, Please refer as follows:
http://www.quickcamteam.net/documentation/how-to/how-to-control-pan-tilt-zoom-on-logitech-cameras


2.QcamMover.exe
This is the GUI of QCAM_PTR.exe, developed on Visual Basic 2010 Express edition.
So, you needs ".netFrameWork 3.5" or later and QCAM_PTR.exe.

Left and Right buttons will move your QCAM to 8 steps, and Up and Down buttons move 6 steps.
RMove button will move relative steps for number of RX and RY.
AMove button will move to absolute position. but it may be not correct when you not push Reset Button.
About button will show about box.

7m4mon@gmail.com
http://nomulabo.com/